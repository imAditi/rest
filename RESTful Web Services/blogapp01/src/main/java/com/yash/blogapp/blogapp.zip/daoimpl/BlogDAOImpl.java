package com.yash.blogapp.daoimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.blogapp.dao.BlogDAO;
import com.yash.blogapp.domain.Blog;
import com.yash.blogapp.rowmapper.BlogRowMapper;
import com.yash.blogapp.util.JNDIConnectionPooling;

public class BlogDAOImpl extends JNDIConnectionPooling implements BlogDAO {

	@Override
	public void insert(Blog blog) {

		String query = "insert into blogs(title,body,created_at,updated_at) values('" + blog.getTitle() + "','"
				+ blog.getBody() + "','" + blog.getCreated_at() + "','" + blog.getUpdated_at() + "')";
		String catQuery = "insert into blogcategories(blog_id,category_id) values('" + blog.getId() + "','"
				+ blog.getCategory() + "')";
		try {
			createPreparedStatement(query).execute();
			createPreparedStatement(catQuery).execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public Blog show(int id) {
		Blog blog = new Blog();
		try {
			ResultSet rs = createPreparedStatement("select * from blogs where id=" + id).executeQuery();
			BlogRowMapper blogRowMapper = new BlogRowMapper();
			blog = blogRowMapper.mapRow(rs, blog);
			ResultSet rs2 = createPreparedStatement("select * from blogcategories where blog_id=" + blog.getId())
					.executeQuery();
			List<Integer> categories = new ArrayList<>();
			while (rs2.next()) {
				categories.add(rs2.getInt("category_id"));
			}
			blog.setCategory(categories);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return blog;
	}

	@Override
	public void update(Blog blog) {
		String query = "UPDATE blogs set title=?,body=?,updated_at=? where id=?";
		String catQuery = "UPDATE blogcategories set category_id=? where blog_id=?";
		PreparedStatement pstmt = createPreparedStatement(query);
		PreparedStatement pstmt2 = createPreparedStatement(catQuery);

		try {
			pstmt.setString(1, blog.getTitle());
			pstmt.setString(2, blog.getBody());
			pstmt.setString(3, blog.getUpdated_at());
			pstmt.setInt(4, blog.getId());
			pstmt.execute();
			// pstmt2.setInt(1, blog.getCategory());
			pstmt2.setInt(2, blog.getId());
			pstmt2.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

	}

	@Override
	public void delete(int id) {
		System.out.println("in delete"+id);
		
		String catQuery = "DELETE from blogcategories where blog_id=?";

		try {
			System.out.println("pstmt cat query");
			PreparedStatement pstmt = createPreparedStatement(catQuery);
			System.out.println("after pstmt cat query");
			pstmt.setInt(1, id);
			System.out.println("set cat query");
			pstmt.execute();
			System.out.println("exe cat query");
			String query = "DELETE from blogs where id=" + id;
			createPreparedStatement(query).execute();
			System.out.println("blog query");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Blog> list() {

		List<Blog> blogs = new ArrayList<>();
		try {
			ResultSet rs = createPreparedStatement(
					"SELECT * FROM blogcategories AS c, blogs AS b WHERE b.`id` = c.`blog_id` GROUP BY c.blog_id")
							.executeQuery();
			
			while (rs.next()) {
				Blog blog = new Blog();
				List<Integer> categories = new ArrayList<>();
				blog.setId(rs.getInt("id"));
				blog.setTitle(rs.getString("title"));
				blog.setBody(rs.getString("body"));
				blog.setCreated_at(rs.getString("created_at"));
				blog.setUpdated_at(rs.getString("updated_at"));

				ResultSet rs2 = createPreparedStatement("SELECT c.category_id FROM blogcategories AS c, blogs AS b "
						+ "WHERE b.`id` = c.`blog_id` AND id=" + blog.getId()).executeQuery();
				while (rs2.next()) {

					categories.add(rs2.getInt("category_id"));
				}
				blog.setCategory(categories);
				blogs.add(blog);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return blogs;
	}

}
